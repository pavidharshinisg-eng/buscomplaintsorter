"""Bus Complaint Sorter starter pipeline. Keyword demo is NOT an LLM."""
from pathlib import Path
import csv, re
from collections import Counter

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "output"
ALLOWED = {"delay", "crowding", "driver", "vehicle", "route_request", "other"}

def load_complaints(path=DATA / "complaints.csv"):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def load_routes(path=DATA / "routes.csv"):
    with open(path, newline="", encoding="utf-8") as f:
        return {int(r["route"]): r["area"] for r in csv.DictReader(f)}

def demo_classify(complaint):
    """Simple local heuristic for pipeline practice; replace with Week 12 LLM API."""
    t = complaint.lower()
    m = re.search(r"\\b(?:route|bus)\\s*(\\d{1,2})\\b", t)
    route = int(m.group(1)) if m else None
    urgent_terms = ["phone while driving", "talking on the phone while driving",
        "rashly", "near miss", "brakes", "door is not closing", "tyre looks damaged",
        "smoking", "hanging on footboard", "standing on the footboard"]
    urgent = any(x in t for x in urgent_terms)
    if any(x in t for x in ["stop near", "add a bus stop", "increase buses"]):
        category = "route_request"
    elif any(x in t for x in ["late", "delay", "romba late"]):
        category = "delay"
    elif any(x in t for x in ["crowd", "crowded", "footboard"]):
        category = "crowding"
    elif any(x in t for x in ["driver", "rude", "phone while driving", "rashly"]):
        category = "driver"
    elif any(x in t for x in ["ac", "door", "tyre", "brake", "seat", "smoking"]):
        category = "vehicle"
    else:
        category = "other"
    summary = " ".join(complaint.split()[:10])
    return {"category": category, "urgent": bool(urgent), "route": route, "summary": summary}

def classify(complaint):
    # TODO: Replace this demo with the API call and prompt.txt from your Week 12 lesson.
    return demo_classify(complaint)

def is_valid(d):
    return (isinstance(d, dict) and set(d) == {"category", "urgent", "route", "summary"}
        and d["category"] in ALLOWED and type(d["urgent"]) is bool
        and (d["route"] is None or type(d["route"]) is int)
        and isinstance(d["summary"], str) and len(d["summary"].split()) <= 12)

def validate_route(route, complaint, route_areas):
    if route is None or route not in route_areas:
        return None
    if re.search(rf"\\b(?:route|bus)\\s*{route}\\b", complaint, re.I):
        return route
    return None

def process_complaints(rows, route_areas):
    output = []
    for row in rows:
        result = None
        status = "processed"
        for attempt in range(2):  # initial attempt plus one retry
            try:
                candidate = classify(row["complaint"])
                if is_valid(candidate):
                    result = candidate
                    break
            except Exception as exc:
                print(f"{row['id']} attempt {attempt + 1} failed: {exc}")
            if attempt == 1:
                status = "needs_manual_review"
        if result is None:
            result = {"category": "other", "urgent": False, "route": None,
                "summary": "Classification needs human review"}
        result["route"] = validate_route(result.get("route"), row["complaint"], route_areas)
        output.append({**row, **result, "status": status})
    return output

def write_reports(records, route_areas):
    OUT.mkdir(exist_ok=True)
    with open(OUT / "results.csv", "w", newline="", encoding="utf-8") as f:
        cols = ["id", "category", "urgent", "route", "summary", "status"]
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader()
        w.writerows({k: r.get(k) for k in cols} for r in records)
    urgent = [r for r in records if r["urgent"]]
    with open(OUT / "urgent.csv", "w", newline="", encoding="utf-8") as f:
        cols = ["id", "date", "route", "area", "complaint", "summary"]
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader()
        for r in urgent:
            route = r.get("route")
            w.writerow({"id": r["id"], "date": r["date"], "route": route,
                "area": route_areas.get(route, "") if route is not None else "",
                "complaint": r["complaint"], "summary": r["summary"]})
    cats = Counter(r["category"] for r in records)
    routes = Counter(r["route"] for r in records if r["route"] is not None)
    manual = sum(r["status"] == "needs_manual_review" for r in records)
    with open(OUT / "summary.txt", "w", encoding="utf-8") as f:
        f.write("BUS COMPLAINT SUMMARY\\n\\nCATEGORY COUNTS\\n")
        for c in sorted(ALLOWED): f.write(f"{c}: {cats.get(c, 0)}\\n")
        f.write("\\nROUTE COUNTS (MOST COMPLAINTS FIRST)\\n")
        for route, count in routes.most_common():
            f.write(f"Route {route} - {route_areas.get(route, 'Unknown area')}: {count}\\n")
        f.write(f"\\nUrgent safety complaints: {len(urgent)}\\nNeeds manual review: {manual}\\n\\nURGENT LIST\\n")
        for r in urgent: f.write(f"{r['id']} | Route {r.get('route') or 'Unknown'} | {r['summary']}\\n")
        f.write("\\nHuman checkpoint: transport officer reviews safety complaints.\\n")
    print("Wrote output/results.csv, output/urgent.csv, output/summary.txt")

def main():
    complaints = load_complaints()
    routes = load_routes()
    print(f"Loaded {len(complaints)} complaints and {len(routes)} routes.")
    processed = process_complaints(complaints, routes)
    write_reports(processed, routes)
    print("Demo complete: keyword classifier only, not an LLM. Integrate your API next.")

if __name__ == "__main__":
    main()
