# Cost and Latency Note — Complete after measuring
- Provider/model:
- Daily complaint count:
- Input tokens per complaint (average):
- Output tokens per complaint (average):
- Input price per million tokens:
- Output price per million tokens:
- Measured average latency per call:
- Retry count/rate:
- Total API calls = complaints + retries:
- Estimated cost per day:

Cost = (input tokens / 1,000,000 × input price) + (output tokens / 1,000,000 × output price). Use current provider pricing and measured usage; don't invent results.
