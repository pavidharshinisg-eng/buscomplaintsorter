# Evaluation Results
Run the five cases in `tests/test_cases.csv`; record actual results (these are expected answers, not test results).
| ID | Expected category | Actual category | Category correct? | Expected urgent | Actual urgent | Urgency correct? | Expected route | Actual route | Route correct? |
|---|---|---|---|---|---|---|---|---|
| T01 | delay | | | false | | | 4 | | |
| T02 | driver | | | true | | | 7 | | |
| T03 | crowding | | | false | | | 2 | | |
| T04 | vehicle | | | true | | | 5 | | |
| T05 | route_request | | | false | | | null | | |
- Category correct:
- Urgency correct:
- Route correct:
- Overall correct / total checks:
- Notes and fixes:
