# Bus Complaint Sorter
Console-based Python project starter for complaint classification, route verification, safety flagging, and reports.

**Important:** `main.py` currently uses a local keyword demo classifier, not an LLM. Use it to test file/report flow, then replace the demo classifier with your Week 12 API integration before calling the AI component complete.

## Run
1. Open this folder in VS Code.
2. Create virtual environment: `python -m venv .venv`
3. Activate on Windows PowerShell: `\.venv\Scripts\Activate.ps1`
4. Run: `python main.py`

It reads `data/complaints.csv` and `data/routes.csv`, then writes `output/results.csv`, `output/urgent.csv`, and `output/summary.txt`.

Sample route-area values are illustrative and are not verified college routes. Update with your official route data if available. Never commit API keys or `.env`.
