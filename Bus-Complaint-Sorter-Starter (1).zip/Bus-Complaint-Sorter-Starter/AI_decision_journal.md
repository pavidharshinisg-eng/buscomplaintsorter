# AI Decision Journal
Fill with actual decisions as you work.
| Date | Decision/problem | AI suggestion (if any) | My decision | Reason/evidence |
|---|---|---|---|---|
| | Dataset | | | |
| | Prompt | | | |
| | Route verification | | | |
| | Retry/fallback | | | |
| | Testing | | | |
