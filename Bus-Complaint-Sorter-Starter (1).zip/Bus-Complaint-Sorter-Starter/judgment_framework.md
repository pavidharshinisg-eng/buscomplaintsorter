# Judgment Framework
| Component | Cost of being wrong | Verify without AI? | Accountable checkpoint |
|---|---|---|---|
| Category | Medium | Partly, by reading complaint | Human reviews uncertain cases |
| Safety flag | High | Yes, human reviews original complaint | Transport officer |
| Route extraction | Medium | Yes, route list and complaint text | Python validation; human if unresolved |
| Summary | Low–medium | Compare with complaint | Human review |
| Counts/report sorting | Low | Yes, Python arithmetic | Developer verifies |
| Final action | High | Not an AI task | Responsible college/transport staff |

The tool organizes and flags only. Safety complaints go to the transport officer. Humans make decisions. It never contacts drivers or decides fault.
