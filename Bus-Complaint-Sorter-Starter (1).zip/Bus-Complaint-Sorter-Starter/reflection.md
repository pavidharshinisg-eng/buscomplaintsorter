# Reflection (target: about 400 words)
Write after finishing. Discuss: problem and motivation; development tools/process; actual challenges; what evaluation and red-team tests showed; what AI should do, what Python verifies and what humans decide; what you learned and future improvements. Do not claim tests or experiences that did not happen.
