# Bus Complaint Sorter — Project Specification
## Problem
Student bus complaints are manually reviewed, which can delay attention to possible safety risks.
## Objective
Build a console-based Python tool that reads complaints and routes, classifies complaints with an LLM, validates fields and route mentions, flags possible safety risks for human review, and generates reports.
## Inputs
- `data/complaints.csv`: at least 20 complaints.
- `data/routes.csv`: 12 route numbers and areas.
## Categories
`delay`, `crowding`, `driver`, `vehicle`, `route_request`, `other`.
## Urgency
Urgent only for potential safety risks: rash/fast driving, phone use while driving, near miss, faulty brakes, unsafe doors/tyres, smoke, or students on the footboard. Rude behaviour alone is not urgent.
## JSON rules
Return exactly: `{"category":"driver","urgent":true,"route":7,"summary":"Route 7 driver used phone while driving"}`. Category must be allowed; urgent must be Boolean; route integer or null; summary no more than 12 words and no names.
## Route verification
Python retains a route only when it exists in `routes.csv` and the number is explicitly mentioned in the complaint. Otherwise route is null. Validate each response, retry once, and after a second failure mark `needs_manual_review`. Handle errors without crashing.
## Outputs
- `output/results.csv`: one row per complaint: id, category, urgent, route, summary, status.
- `output/urgent.csv`: id, date, route, area, original complaint, summary.
- `output/summary.txt`: category counts, route counts sorted descending, urgent list, manual-review count.
## Human checkpoint and limitations
The transport officer reviews safety complaints. Humans decide actions. The tool never contacts drivers or decides fault.
